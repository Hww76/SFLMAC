import argparse
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from Algorithm.SFLMAC.strategy import build_sflmac_pairs
from config import training as training_config
from utils.time.load_calculate import calculate_model_loads_by_layer
from utils.time.time_ctrl import set_client_LBFSL


plt.rcParams.update({
    "font.size": 13,
    "axes.labelsize": 15,
    "axes.titlesize": 16,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "legend.fontsize": 12,
    "lines.linewidth": 2.0,
})


def build_splitpoint_flops(benchmark: str, bs: int):
    forward, backward, _, _ = calculate_model_loads_by_layer(benchmark=benchmark, batch_size=bs)

    real_forward = forward
    real_backward = backward
    if len(forward) > 1 and forward[0] == 0:
        real_forward = forward[1:]
        real_backward = backward[1:]

    f_self = [0]
    b_self = [0]
    for i in range(1, len(real_forward) + 1):
        f_self.append(f_self[-1] + real_forward[i - 1])
        b_self.append(b_self[-1] + real_backward[i - 1])

    f_helper = [0]
    b_helper = [0]
    for i in range(1, len(f_self)):
        f_helper.append(f_self[-1] - f_self[i])
        b_helper.append(b_self[-1] - b_self[i])

    return f_self, b_self, f_helper, b_helper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=str, default="resnet18_cifar10")
    parser.add_argument("--num_client", type=int, default=16)
    parser.add_argument("--local_epoch", type=int, default=64)
    parser.add_argument("--bs", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--split_point", type=int, default=None, help="固定分割点；为空时按pair自适应选择")
    parser.add_argument("--output_dir", type=str, default="result_diff_splitpoint_diff_clientnum/IID_alpha5/resnet18_cifar10/plots")
    args = parser.parse_args()

    np.random.seed(args.seed)

    f_self, b_self, f_helper, b_helper = build_splitpoint_flops(args.benchmark, args.bs)
    max_split_point = len(f_self) - 1

    valid_split_points = None
    if "resnet18" in args.benchmark:
        valid_split_points = list(getattr(training_config, "RESNET18_VALID_SPLIT_POINTS", []))

    # data_sizes only affects batch counters/time, not pairing load criterion.
    data_sizes = [args.bs for _ in range(args.num_client)]
    clients = set_client_LBFSL(
        num_client=args.num_client,
        data_sizes=data_sizes,
        local_epoch=args.local_epoch,
        minibatch=args.bs,
        benchmark=args.benchmark,
        forward_flops_by_splitpoint_list_self=f_self,
        backward_flops_by_splitpoint_list_self=b_self,
        forward_flops_by_splitpoint_list_helper=f_helper,
        backward_flops_by_splitpoint_list_helper=b_helper,
        parameter_bits_by_splitpoint_list_self=[0] * len(f_self),
        parameter_bits_by_splitpoint_list_helper=[0] * len(f_helper),
        split_point=max_split_point,
    )

    pair_info = build_sflmac_pairs(
        clients=clients,
        max_split_point=max_split_point,
        forward_flops_by_splitpoint_list_self=f_self,
        backward_flops_by_splitpoint_list_self=b_self,
        forward_flops_by_splitpoint_list_helper=f_helper,
        backward_flops_by_splitpoint_list_helper=b_helper,
        shared_split_point=args.split_point,
        debug=False,
        valid_split_points=valid_split_points,
    )

    full_model_flops = f_self[-1] + b_self[-1]
    initial_loads = [full_model_flops / c.computing for c in clients]
    after_loads = [pair_info["client_loads"][i] for i in range(args.num_client)]

    # aux group: sort by computing ascending and show selected split points.
    aux_rows = []
    role_map = pair_info.get("role_map", {})
    pair_split_points = pair_info.get("pair_split_points", {})
    for (main_id, aux_id), split in pair_split_points.items():
        if role_map.get(aux_id) == "aux":
            aux_rows.append((aux_id, clients[aux_id].computing, split, main_id))

    aux_rows.sort(key=lambda x: x[1])

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Figure 1: load before vs after pairing.
    fig1, ax1 = plt.subplots(figsize=(8, 5))
    x = np.arange(args.num_client)
    ax1.plot(
        x,
        initial_loads,
        color="#1f77b4",
        linestyle="-",
        marker="o",
        markevery=max(1, len(x) // 12),
        label="Before Pairing",
    )
    ax1.plot(
        x,
        after_loads,
        color="#ff7f0e",
        linestyle="--",
        marker="s",
        markevery=max(1, len(x) // 12),
        label="After Pairing",
    )
    ax1.set_xlabel("Client ID")
    ax1.set_ylabel("Load (FLOPs / computing)")
    # ax1.set_title("SFLMAC Client Load: Before vs After Pairing")
    ax1.grid(True, linestyle=":", alpha=0.4)
    ax1.legend()
    fig1.tight_layout()
    fig1_path = output_dir / f"sflmac_load_before_after_n{args.num_client}_seed{args.seed}.pdf"
    fig1.savefig(fig1_path, dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig1)

    # Figure 2: aux computing order -> selected split point.
    fig2, ax2 = plt.subplots(figsize=(8, 5))
    if aux_rows:
        x2 = np.arange(1, len(aux_rows) + 1)
        y2 = [row[2] for row in aux_rows]
        labels = [f"aux{row[0]}" for row in aux_rows]
        ax2.plot(
            x2,
            y2,
            color="#d62728",
            linestyle=":",
            marker="D",
            markevery=max(1, len(x2) // 10),
        )
        ax2.set_xticks(x2)
        ax2.set_xticklabels(labels, rotation=0)
    ax2.set_xlabel("Aux Clients Sorted by Computing (low -> high)")
    ax2.set_ylabel("Selected Cut Layer")
    # ax2.set_title("Split Point Selection in Aux Group (N=16)")
    ax2.grid(True, linestyle=":", alpha=0.4)
    fig2.tight_layout()
    fig2_path = output_dir / f"sflmac_aux_sorted_splitpoint_n{args.num_client}_seed{args.seed}.pdf"
    fig2.savefig(fig2_path, dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig2)

    print(f"[OK] Saved: {fig1_path}")
    print(f"[OK] Saved: {fig2_path}")


if __name__ == "__main__":
    main()

import argparse
from pathlib import Path
from dataclasses import replace
from typing import Dict, List, Tuple
import sys

import matplotlib.pyplot as plt
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from config.communication import (
    communication_cost_per_round_bits,
    get_resnet18_average_qbar_bits_per_minibatch,
    get_resnet18_split_profiles,
)


plt.rcParams.update({
    "font.size": 30,
    "axes.labelsize": 32,
    "xtick.labelsize": 22,
    "ytick.labelsize": 22,
    "legend.fontsize": 28,
    "lines.linewidth": 2.2,
    "axes.linewidth": 1.1,
})


def parse_int_list(raw: str) -> List[int]:
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


def parse_str_list(raw: str) -> List[str]:
    return [x.strip() for x in raw.split(",") if x.strip()]


def bits_to_unit(bits: float, unit: str) -> float:
    unit_upper = unit.upper()
    if unit_upper == "MB":
        return bits / 8.0 / 1e6
    if unit_upper == "GB":
        return bits / 8.0 / 1e9
    raise ValueError(f"Unsupported unit: {unit}")


def normalize_method_name(algorithm_name: str) -> str:
    key = algorithm_name.strip().lower()
    mapping = {
        "fedavg": "FL",
        "f": "FL",
        "fl": "FL",
        "splitfed": "SplitFed",
        "ringsfl": "RingSFL",
        "sflmac": "SFLMAC",
    }
    if key not in mapping:
        raise ValueError(f"Unsupported algorithm for communication formula: {algorithm_name}")
    return mapping[key]


def find_run_dir(
    root: Path,
    benchmark: str,
    global_epoch: int,
    local_epoch: int,
    num_client: int,
    split_point: int,
    algorithm: str,
) -> Path:
    run_dir = root / benchmark / f"global_epoch{global_epoch}_local_epoch{local_epoch}_num_client{num_client}_sp{split_point}"
    return run_dir / algorithm


def load_one_point(run_dir: Path, global_epoch: int, acc_metric: str, unit: str) -> Tuple[float, float]:
    acc_path = run_dir / "acc1.npy"
    comm_path = run_dir / "comm_total_bits.npy"

    if not acc_path.exists() or not comm_path.exists():
        raise FileNotFoundError(f"Missing npy files in {run_dir}")

    acc = np.asarray(np.load(acc_path), dtype=np.float64).reshape(-1)
    comm = np.asarray(np.load(comm_path), dtype=np.float64).reshape(-1)
    if acc.size == 0:
        raise ValueError(f"Empty acc1.npy in {run_dir}")
    if comm.size < 3:
        raise ValueError(f"comm_total_bits.npy must contain at least 3 values in {run_dir}")

    if acc_metric == "best":
        y_acc = float(np.max(acc))
    elif acc_metric == "last":
        y_acc = float(acc[-1])
    else:
        raise ValueError(f"Unsupported acc_metric: {acc_metric}")

    total_bits = float(comm[2])
    per_round_bits = total_bits / float(global_epoch)
    x_comm = bits_to_unit(per_round_bits, unit)
    return x_comm, y_acc


def load_accuracy_curve(run_dir: Path) -> np.ndarray:
    acc_path = run_dir / "acc1.npy"
    if not acc_path.exists():
        raise FileNotFoundError(f"Missing acc1.npy in {run_dir}")
    acc = np.asarray(np.load(acc_path), dtype=np.float64).reshape(-1)
    if acc.size == 0:
        raise ValueError(f"Empty acc1.npy in {run_dir}")
    return acc


def get_per_round_bits_by_formula(
    benchmark: str,
    split_point: int,
    algorithm: str,
    num_client: int,
    local_epoch: int,
    batch_size: int,
    num_upper_clients: int,
) -> float:
    profiles = get_resnet18_split_profiles(
        benchmark=benchmark,
        batch_size=batch_size,
        split_points=[split_point],
    )
    profile = profiles[split_point]

    method = normalize_method_name(algorithm)
    if method.lower() == "ringsfl":
        # RingSFL uses average activation communication with minibatch size included.
        avg_qbar = get_resnet18_average_qbar_bits_per_minibatch(
            benchmark=benchmark,
            batch_size=batch_size,
        )
        profile = replace(profile, qbar_bits_per_minibatch=int(avg_qbar))

    kwargs = {
        "method": method,
        "num_clients": num_client,
        "local_iterations": local_epoch,
        "profile": profile,
    }
    if method.lower() == "parallelsfl":
        kwargs["num_upper_clients"] = num_upper_clients

    return float(communication_cost_per_round_bits(**kwargs)["total_system_bits"])


def collect_curves_for_split(
    root: Path,
    benchmark: str,
    global_epoch: int,
    local_epoch: int,
    num_client: int,
    split_point: int,
    algorithms: List[str],
    unit: str,
    batch_size: int,
    num_upper_clients: int,
) -> Tuple[Dict[str, Tuple[np.ndarray, np.ndarray]], List[str]]:
    curves: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    warnings: List[str] = []

    for algo in algorithms:
        run_dir = find_run_dir(root, benchmark, global_epoch, local_epoch, num_client, split_point, algo)
        if not run_dir.exists():
            warnings.append(f"[WARN] Missing run dir: {run_dir}")
            continue

        try:
            acc = load_accuracy_curve(run_dir)
            per_round_bits = get_per_round_bits_by_formula(
                benchmark=benchmark,
                split_point=split_point,
                algorithm=algo,
                num_client=num_client,
                local_epoch=local_epoch,
                batch_size=batch_size,
                num_upper_clients=num_upper_clients,
            )
            x_vals = bits_to_unit(per_round_bits, unit) * np.arange(1, len(acc) + 1, dtype=np.float64)
            curves[algo] = (x_vals, acc)
        except (FileNotFoundError, ValueError) as exc:
            warnings.append(f"[WARN] {exc}")

    return curves, warnings


def plot_curves_for_split(
    curves: Dict[str, Tuple[np.ndarray, np.ndarray]],
    output_path: Path,
    unit: str,
    benchmark: str,
    num_client: int,
    local_epoch: int,
    global_epoch: int,
    split_point: int,
    x_center_algo: str,
):
    fig, ax = plt.subplots(figsize=(10, 6))

    line_styles = ["-", "--", ":", "-."]
    markers = ["o", "s", "^", "D", "v", "P", "X", "*"]

    x_all = []
    has_any_line = False
    for idx, (algo, (x_vals, y_vals)) in enumerate(curves.items()):
        style = line_styles[idx % len(line_styles)]
        marker = markers[idx % len(markers)]
        ax.plot(
            x_vals,
            y_vals,
            label=algo,
            linestyle=style,
            marker=marker,
            markevery=max(1, len(x_vals) // 12),
            markersize=7,
        )
        x_all.extend(x_vals.tolist())
        has_any_line = True

    if not has_any_line:
        raise RuntimeError("No valid curves found for this split point.")

    x_mid = None
    if x_center_algo in curves:
        x_mid = float(curves[x_center_algo][0][-1])
    else:
        x_mid = float(max(x_all)) / 2.0
        print(f"[WARN] x_center_algo={x_center_algo} not found for sp={split_point}, fallback to midpoint from global max")

    x_right = 2.0 * x_mid
    if x_right <= 0:
        x_right = float(max(x_all))

    ax.set_xlim(left=0.0, right=x_right)
    ticks = np.linspace(0.0, x_right, 6)
    ax.set_xticks(ticks)

    ax.set_xlabel(f"Communication Cost ({unit.upper()})")
    ax.set_ylabel("Accuracy (Top-1)")
    # ax.set_title(
    #     f"{benchmark}: Accuracy vs Communication (sp={split_point}, N={num_client}, K={local_epoch}, E={global_epoch})"
    # )
    ax.grid(True, linestyle=":", alpha=0.4)
    ax.legend()
    fig.tight_layout()

    output_path.parent.mkdir(parents=True, exist_ok=True)
    png_path = output_path.with_suffix(".png")
    pdf_path = output_path.with_suffix(".pdf")
    fig.savefig(png_path, dpi=300, format="png", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(pdf_path, dpi=300, format="pdf", bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    return png_path, pdf_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=str, default="result_diff_splitpoint_diff_clientnum/IID_alpha5")
    parser.add_argument("--benchmark", type=str, default="resnet18_cifar10")
    parser.add_argument("--global_epoch", type=int, default=50)
    parser.add_argument("--local_epoch", type=int, default=64)
    parser.add_argument("--num_client", type=int, default=16)
    parser.add_argument("--split_points", type=str, default="5,9,13")
    parser.add_argument("--algorithms", type=str, default="FedAvg,SplitFed,RingSFL,SFLMAC")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--num_upper_clients", type=int, default=1)
    parser.add_argument("--unit", type=str, choices=["MB", "GB"], default="GB")
    parser.add_argument("--x_center_algo", type=str, default="SplitFed")
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    split_points = parse_int_list(args.split_points)
    algorithms = parse_str_list(args.algorithms)

    for sp in split_points:
        curves, warnings = collect_curves_for_split(
            root=root,
            benchmark=args.benchmark,
            global_epoch=args.global_epoch,
            local_epoch=args.local_epoch,
            num_client=args.num_client,
            split_point=sp,
            algorithms=algorithms,
            unit=args.unit,
            batch_size=args.batch_size,
            num_upper_clients=args.num_upper_clients,
        )

        for w in warnings:
            print(w)

        if args.output:
            base = Path(args.output).resolve()
            output_path = base.parent / f"{base.stem}_sp{sp}_{args.unit.lower()}"
        else:
            output_path = (
                root
                / args.benchmark
                / "plots"
                / f"acc_vs_comm_sp{sp}_n{args.num_client}_k{args.local_epoch}_e{args.global_epoch}_{args.unit.lower()}"
            )

        try:
            png_path, pdf_path = plot_curves_for_split(
                curves=curves,
                output_path=output_path,
                unit=args.unit,
                benchmark=args.benchmark,
                num_client=args.num_client,
                local_epoch=args.local_epoch,
                global_epoch=args.global_epoch,
                split_point=sp,
                x_center_algo=args.x_center_algo,
            )
            print(f"[OK] Saved: {png_path}")
            print(f"[OK] Saved: {pdf_path}")
        except RuntimeError as exc:
            print(f"[WARN] split_point={sp} skipped: {exc}")


if __name__ == "__main__":
    main()

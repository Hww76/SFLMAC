from pathlib import Path
import argparse

import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 16,
    'axes.labelsize': 14,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 12,
    'lines.linewidth': 2.0,
    'axes.linewidth': 1.2,
    'xtick.major.width': 1.2,
    'ytick.major.width': 1.2,
})


def load_sweep_data(run_dir: Path) -> tuple[np.ndarray, np.ndarray]:
    client_path = run_dir / 'clientnum.npy'
    global_time_path = run_dir / 'globaltime.npy'

    if not client_path.exists() or not global_time_path.exists():
        raise FileNotFoundError(
            f'未找到所需文件：{client_path} 或 {global_time_path}'
        )

    client_nums = np.load(client_path).reshape(-1)
    global_times = np.load(global_time_path).reshape(-1)

    if client_nums.size != global_times.size:
        raise ValueError(
            f'数据长度不一致：clientnum={client_nums.size}, globaltime={global_times.size}'
        )

    sorted_idx = np.argsort(client_nums)
    client_nums = client_nums[sorted_idx]
    global_times = global_times[sorted_idx]

    return client_nums, global_times


def plot_clientnum_globaltime_multi(
    sweep_dirs: list[tuple[str, Path]],
    output_path: Path,
) -> tuple[Path, Path]:
    if len(sweep_dirs) == 0:
        raise ValueError('sweep_dirs 不能为空')

    plt.figure(figsize=(8, 5))

    for label, run_dir in sweep_dirs:
        client_nums, global_times = load_sweep_data(run_dir)
        plt.plot(client_nums, global_times, linestyle='-', label=label)

    plt.xlabel('Number of Clients')
    plt.ylabel('Global Iteration Time (s)')
    plt.title('Global Iteration Time vs Number of Clients')
    plt.grid(True, linestyle=':', alpha=0.5)

    if len(sweep_dirs) > 1:
        plt.legend()

    plt.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base_path = output_path.with_suffix('')
    eps_path = base_path.with_suffix('.eps')
    png_path = base_path.with_suffix('.png')
    plt.savefig(eps_path, format='eps', dpi=300)
    plt.savefig(png_path, format='png', dpi=300)
    plt.close()

    return eps_path, png_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--find_dir', type=str, required=True,
                        help='待比较目录，内部结构为 find_dir/AlgorithmName/')
    parser.add_argument('--algorithms', type=str, default='FSL,FedAvg,FSCL',
                        help='要比较的算法列表，逗号分隔，例如: FSL,FedAvg,FSCL')
    arg = parser.parse_args()

    find_dir = Path(arg.find_dir)
    algorithms = [item.strip() for item in arg.algorithms.split(',') if item.strip()]
    sweep_dirs: list[tuple[str, Path]] = [(name, find_dir / name) for name in algorithms]

    missing = [name for name, run_dir in sweep_dirs if not run_dir.is_dir()]
    if missing:
        raise FileNotFoundError(f'未找到算法目录: {missing}，期望路径为 {find_dir}/<Algorithm>/')

    output_path = find_dir / 'globaltime_vs_clientnum_multi.eps'
    eps_path, png_path = plot_clientnum_globaltime_multi(sweep_dirs, output_path)
    print(f'绘图完成：{eps_path}')
    print(f'绘图完成：{png_path}')


if __name__ == '__main__':
    main()

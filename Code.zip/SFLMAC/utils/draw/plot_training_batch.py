import argparse
from pathlib import Path

import numpy as np

from plot_training import (
    find_runs,
    load_arrays,
    plot_multiple,
    str2bool,
)


def parse_csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def distribution_prefix(distribution: str) -> str:
    lower_name = distribution.lower()
    marker = "_alpha"
    idx = lower_name.find(marker)
    if idx == -1:
        return distribution
    return distribution[:idx]


def find_benchmark_run_dirs(benchmark_dir: Path, targets: list[str]) -> list[tuple[str, Path]]:
    child_dirs = [p for p in benchmark_dir.iterdir() if p.is_dir()]
    if not child_dirs:
        return []

    # If algorithms are directly under benchmark dir, use benchmark dir itself as a run dir.
    child_names = {p.name for p in child_dirs}
    if any(name in child_names for name in targets):
        return [("default", benchmark_dir)]

    run_dirs: list[tuple[str, Path]] = []
    for child in sorted(child_dirs):
        if any((child / algo).is_dir() for algo in targets):
            run_dirs.append((child.name, child))
    return run_dirs


def build_runs_data(
    run_dir: Path,
    targets: list[str],
    use_time: bool,
) -> tuple[dict[str, tuple[np.ndarray, np.ndarray]], list[str], str]:
    runs = find_runs(str(run_dir), targets)
    missing = [name for name in targets if name not in runs]
    if not runs:
        return {}, missing, ""

    runs_data: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    x_label = "Time (s)" if use_time else "Communication Round"
    for algorithm, info in runs.items():
        acc_path, time_path = info["acc_time"]
        acc, time = load_arrays(acc_path, time_path)

        x_values = time if use_time else np.arange(1, len(acc) + 1)
        runs_data[algorithm] = (acc, x_values)
    return runs_data, missing, x_label


def main():
    parser = argparse.ArgumentParser(
        description="Batch-generate algorithm comparison plots for all benchmarks under multiple data distributions."
    )
    parser.add_argument(
        "--results_root",
        type=str,
        default="./results",
        help="Root path containing distribution folders (e.g., IID_alpha5, NonIID_alpha0.2).",
    )
    parser.add_argument(
        "--distributions",
        type=str,
        default="IID_alpha5,NonIID_alpha0.2",
        help="Distribution folder names under results_root, comma-separated.",
    )
    parser.add_argument(
        "--algorithms",
        type=str,
        default="FedAvg,SplitFed,RingSFL,SFLMAC",
        help="Algorithms to compare, comma-separated.",
    )
    parser.add_argument(
        "--use_time",
        type=str2bool,
        default=False,
        help="Use time on x-axis if True, otherwise communication round.",
    )
    args = parser.parse_args()

    results_root = Path(args.results_root)
    distributions = parse_csv(args.distributions)
    targets = parse_csv(args.algorithms)
    if not distributions:
        raise ValueError("No distributions specified.")
    if not targets:
        raise ValueError("No algorithms specified.")

    total_plots = 0
    for distribution in distributions:
        distribution_dir = results_root / distribution
        dist_prefix = distribution_prefix(distribution)
        if not distribution_dir.is_dir():
            print(f"Skip missing distribution directory: {distribution_dir}")
            continue

        benchmark_dirs = sorted([p for p in distribution_dir.iterdir() if p.is_dir()])
        if not benchmark_dirs:
            print(f"No benchmark directories found under: {distribution_dir}")
            continue

        for benchmark_dir in benchmark_dirs:
            benchmark = benchmark_dir.name
            run_dirs = find_benchmark_run_dirs(benchmark_dir, targets)
            if not run_dirs:
                print(f"Skip benchmark (no run dir with target algorithms): {benchmark_dir}")
                continue

            for env_key, run_dir in run_dirs:
                runs_data, missing, x_label = build_runs_data(run_dir, targets, args.use_time)
                if not runs_data:
                    print(f"Skip run (no valid algorithm data): {run_dir}")
                    continue

                if missing:
                    print(
                        f"Warning: missing algorithms in {run_dir}: {missing}. "
                        f"Plotting available algorithms: {list(runs_data.keys())}"
                    )

                title = f"{distribution} | {benchmark} ({env_key})"
                output_name = f"{dist_prefix}_{benchmark}_{env_key}.pdf"
                output_path = distribution_dir / output_name
                plot_multiple(runs_data, str(output_path), title=title, x_label=x_label)
                total_plots += 1

    print(f"Done. Generated {total_plots} plot(s).")


if __name__ == "__main__":
    main()

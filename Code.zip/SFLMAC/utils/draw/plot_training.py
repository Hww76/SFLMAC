import os
import argparse
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.size': 30,
    'axes.titlesize': 32,
    'axes.labelsize': 30,
    'xtick.labelsize': 22,
    'ytick.labelsize': 22,
    'legend.fontsize': 28,
    'lines.linewidth': 2.0,
    'axes.linewidth': 1.2,
    'xtick.major.width': 1.2,
    'ytick.major.width': 1.2,
})


def find_acc_time_pair(subdir: str):
    acc_simple = os.path.join(subdir, "acc.npy")
    acc1_simple = os.path.join(subdir, "acc1.npy")
    time_simple = os.path.join(subdir, "time.npy")
    if os.path.exists(acc_simple) and os.path.exists(time_simple):
        return acc_simple, time_simple
    if os.path.exists(acc1_simple) and os.path.exists(time_simple):
        return acc1_simple, time_simple

    candidates = []
    for fname in os.listdir(subdir):
        if fname.endswith("_acc.npy") or fname.endswith("_acc1.npy"):
            candidates.append(os.path.join(subdir, fname))
    if not candidates:
        return None

    acc_path = max(candidates, key=os.path.getmtime)
    if acc_path.endswith("_acc.npy"):
        base = acc_path[:-len("_acc.npy")]
    else:
        base = acc_path[:-len("_acc1.npy")]
    time_path = base + "_time.npy"
    if os.path.exists(time_path):
        return acc_path, time_path
    return None


def find_run_for_algorithm(find_dir: str, algorithm: str):
    algo_dir = os.path.join(find_dir, algorithm)
    if not os.path.isdir(algo_dir):
        return None
    return algo_dir


def find_runs(find_dir: str, targets: list[str] = ["FedAvg", "SplitFed", "RingSFL", "SFLMAC"]):
    runs = {}
    for algorithm in targets:
        run_dir = find_run_for_algorithm(find_dir, algorithm)
        if run_dir is None:
            continue

        pair = find_acc_time_pair(run_dir)
        if pair:
            runs[algorithm] = {
                "run_dir": run_dir,
                "kind": "npy",
                "acc_time": pair,
            }
    return runs


def load_arrays(acc_path: str, time_path: str):
    acc = np.load(acc_path)
    time = np.load(time_path)
    acc = np.asarray(acc).reshape(-1)
    time = np.asarray(time).reshape(-1)
    if acc.size != time.size:
        if time.size == acc.size + 1:
            time = time[1:]
        else:
            n = min(acc.size, time.size)
            acc = acc[:n]
            time = time[:n]
        print(f"Warning: length mismatch, aligned to {len(acc)} elements.")
    return acc, time


# def parse_benchmark_from_find_dir(find_dir: str) -> str | None:
#     path = Path(find_dir).resolve()
#     parts = [p for p in path.parts if p]
#     for part in parts:
#         low = part.lower()
#         if low.endswith("_cifar10") or low.endswith("_cifar100"):
#             return part
#     if path.name.startswith("global_epoch"):
#         return path.parent.name
#     if path.name:
#         return path.name
#     return None


def str2bool(v):
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("1", "true", "t", "yes", "y", "on"):
        return True
    if s in ("0", "false", "f", "no", "n", "off"):
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {v}")


def plot_multiple(
    runs_data: dict[str, tuple[np.ndarray, np.ndarray]],
    output_path: str,
    title: str,
    x_label: str,
):
    plt.figure(figsize=(10, 6))
    for label, (acc, x_values) in runs_data.items():
        plt.plot(x_values, acc, linestyle="-", label=label)
    # plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel("Accuracy (Top-1)")
    plt.grid(True, linestyle=":", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    output_path_obj = Path(output_path)
    base_path = output_path_obj.with_suffix('')
    pdf_path = base_path.with_suffix('.pdf')
    png_path = base_path.with_suffix('.png')
    plt.savefig(pdf_path, format='pdf', dpi=300)
    plt.savefig(png_path, format='png', dpi=300)
    print(f"Saved plot to: {pdf_path}")
    print(f"Saved plot to: {png_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--algorithms', type=str, default='FedAvg,SplitFed,RingSFL,SFLMAC',
                        help='要比较的算法列表，逗号分隔，例如: FedAvg,FSCL,FSL')
    parser.add_argument(
        '--use_time',
        type=str2bool,
        default=False,
        help='横坐标是否使用时间。True: 时间；False: 全局迭代轮数',
    )
    arg = parser.parse_args()

    # model = "alexnet"
    # model = "resnet18"
    model = "vgg16"
    dataset = "cinic10"
    
    benchmark = model + "_" + dataset
    # find_dir = "./results_cinic10/IID_alpha5/" + benchmark + "/global_epoch100_local_epoch64_num_client20"
    find_dir = "./results_cinic10/NonIID_alpha0.2/" + benchmark + "/global_epoch100_local_epoch64_num_client20"
    targets = [item.strip() for item in arg.algorithms.split(',') if item.strip()]
    runs = find_runs(find_dir, targets)
    missing = [name for name in targets if name not in runs]
    if missing:
        raise FileNotFoundError(
            f"Cannot find matching runs for: {missing}. "
            f"Need directories and npy files under {find_dir}/<Algorithm>/"
        )

    runs_data: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for algorithm, info in runs.items():
        acc_path, time_path = info["acc_time"]
        acc, time = load_arrays(acc_path, time_path)

        if arg.use_time:
            x_values = time
            x_label = "Time (s)"
        else:
            x_values = np.arange(1, len(acc) + 1)
            x_label = "Communication Round"
        runs_data[algorithm] = (acc, x_values)

    # benchmark = parse_benchmark_from_find_dir(find_dir) or "Accuracy_vs_Time"
    env_key = Path(find_dir).name
    title = f"{benchmark} ({env_key})"
    output_path = os.path.join(find_dir, f"{benchmark}_{env_key}.pdf")
    plot_multiple(runs_data, output_path, title, x_label=x_label)

if __name__ == "__main__":
    main()

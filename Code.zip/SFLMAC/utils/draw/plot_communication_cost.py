import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def load_summary(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def resolve_output_path_by_metric(
    root: Path,
    run_dir: str,
    benchmark: str,
    output_arg: str | None,
    metric: str,
) -> Path:
    if output_arg is None:
        return root / f"communication_cost_{metric}_{benchmark}_{run_dir}.pdf"

    base = Path(output_arg)
    if len(base.suffix) > 0:
        return base.with_name(f"{base.stem}_{metric}_{benchmark}.pdf")

    return base / f"communication_cost_{metric}_{benchmark}_{run_dir}.pdf"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=str, default="results/communication")
    parser.add_argument("--benchmark", type=str, default="vgg16_fashionmnist")
    parser.add_argument("--benchmarks", type=str, nargs="+", default=None)
    parser.add_argument("--global_epoch", type=int, default=1)
    parser.add_argument("--local_epoch", type=int, default=64)
    parser.add_argument("--num_client", type=int, default=20)
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    root = Path(args.root)
    run_dir = f"global_epoch{args.global_epoch}_local_epoch{args.local_epoch}_num_client{args.num_client}"
    algorithms = ["FedAvg", "SFL", "RingSFL", "SFLMAC"]

    benchmark_list = args.benchmarks if args.benchmarks else [args.benchmark]

    saved_outputs = []
    for benchmark in benchmark_list:
        model_bytes = []
        activation_bytes = []
        labels = []

        for algo in algorithms:
            summary_path = root / algo / benchmark / run_dir / "summary.json"
            if not summary_path.exists():
                print(f"[WARN] Missing summary: {summary_path}")
                continue
            summary = load_summary(summary_path)
            labels.append(algo)
            model_bytes.append(float(summary.get("model_bits", 0)) / 8.0)
            activation_bytes.append(float(summary.get("activation_bits", 0)) / 8.0)

        if not labels:
            continue

        x = np.arange(len(labels))
        # Figure 1: model transfer only
        fig_model, ax_model = plt.subplots(figsize=(8, 5))
        ax_model.bar(x, model_bytes, width=0.5, label="Model Transfer (Bytes)")
        ax_model.set_xticks(x)
        ax_model.set_xticklabels(labels)
        ax_model.set_ylabel("Bytes")
        ax_model.set_title("Model Transfer Cost")
        ax_model.legend()
        ax_model.grid(axis="y", linestyle="--", alpha=0.3)

        for idx in range(len(labels)):
            ax_model.text(x[idx], model_bytes[idx], f"{model_bytes[idx]:.2e}", ha="center", va="bottom", fontsize=8)

        output_path_model = resolve_output_path_by_metric(root, run_dir, benchmark, args.output, "model")
        output_path_model.parent.mkdir(parents=True, exist_ok=True)
        plt.tight_layout()
        plt.savefig(output_path_model, dpi=300, format="pdf")
        plt.close(fig_model)
        saved_outputs.append(output_path_model)

        # Figure 2: activation transfer only
        fig_activation, ax_activation = plt.subplots(figsize=(8, 5))
        ax_activation.bar(x, activation_bytes, width=0.5, label="Activation Transfer (Bytes)")
        ax_activation.set_xticks(x)
        ax_activation.set_xticklabels(labels)
        ax_activation.set_ylabel("Bytes")
        ax_activation.set_title("Activation Transfer Cost")
        ax_activation.legend()
        ax_activation.grid(axis="y", linestyle="--", alpha=0.3)

        for idx in range(len(labels)):
            ax_activation.text(x[idx], activation_bytes[idx], f"{activation_bytes[idx]:.2e}", ha="center", va="bottom", fontsize=8)

        output_path_activation = resolve_output_path_by_metric(root, run_dir, benchmark, args.output, "activation")
        output_path_activation.parent.mkdir(parents=True, exist_ok=True)
        plt.tight_layout()
        plt.savefig(output_path_activation, dpi=300, format="pdf")
        plt.close(fig_activation)
        saved_outputs.append(output_path_activation)

    if not saved_outputs:
        raise FileNotFoundError("No communication summary files found. Please run run_comm_one_round.sh or run_comm_three_models.sh first.")
    for p in saved_outputs:
        print(f"[OK] Saved plot to: {p}")


if __name__ == "__main__":
    main()

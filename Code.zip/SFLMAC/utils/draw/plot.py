import re
import argparse
from pathlib import Path
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 16,
    'axes.labelsize': 14,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 12,
    'lines.linewidth': 2.0,
    'axes.linewidth': 1.2,
    'xtick.major.width': 1.2,
    'ytick.major.width': 1.2,
})

parser = argparse.ArgumentParser()
parser.add_argument('--find_dir', type=str, required=True,
                    help='待比较目录，内部结构为 find_dir/AlgorithmName/')
parser.add_argument('--algorithms', type=str, required=True,
                    help='要比较的算法列表，逗号分隔，例如: FSCL,FedAvg')
args = parser.parse_args()

find_dir = Path(args.find_dir)
algorithms = [item.strip() for item in args.algorithms.split(',') if item.strip()]

files = {}
for algorithm in algorithms:
    algo_dir = find_dir / algorithm
    if not algo_dir.is_dir():
        raise FileNotFoundError(f'未找到算法目录: {algo_dir}')

    txt_candidates = sorted(algo_dir.glob('*.txt'), key=lambda p: p.stat().st_mtime)
    if not txt_candidates:
        raise FileNotFoundError(f'目录下未找到 .txt 日志文件: {algo_dir}')
    files[algorithm] = txt_candidates[-1]

pattern = re.compile(r"epoch=(\d+)\s+loss_avg=([0-9.]+)\s+acc1=([0-9.]+)")

data = {}
for label, path in files.items():
    epochs, loss, acc1 = [], [], []
    text = path.read_text(encoding='utf-8')
    for line in text.splitlines():
        m = pattern.search(line)
        if not m:
            continue
        epochs.append(int(m.group(1)))
        loss.append(float(m.group(2)))
        acc1.append(float(m.group(3)))
    data[label] = (epochs, loss, acc1)

out_dir = find_dir
out_dir.mkdir(parents=True, exist_ok=True)

# acc1 plot
plt.figure(figsize=(10,6))
for label, (epochs, loss, acc1) in data.items():
    plt.plot(epochs, acc1, marker='o', linestyle='-', label=label)
plt.xlabel('Epoch')
plt.ylabel('Accuracy (acc1)')
plt.title('Accuracy (acc1)')
plt.grid(True, linestyle=':', alpha=0.5)
plt.legend()
plt.tight_layout()
acc_path = out_dir / 'acc1_comparison.eps'
acc_base = acc_path.with_suffix('')
acc_eps_path = acc_base.with_suffix('.eps')
acc_png_path = acc_base.with_suffix('.png')
plt.savefig(acc_eps_path, format='eps', dpi=300)
plt.savefig(acc_png_path, format='png', dpi=300)
plt.close()

# # loss plot
# plt.figure(figsize=(10,6))
# for label, (epochs, loss, acc1) in data.items():
#     plt.plot(epochs, loss, marker='o', linestyle='-', label=label)
# plt.xlabel('Epoch')
# plt.ylabel('Loss')
# plt.title('Loss')
# plt.grid(True, linestyle=':', alpha=0.5)
# plt.legend()
# plt.tight_layout()
# loss_path = out_dir / 'loss_comparison.eps'
# loss_base = loss_path.with_suffix('')
# plt.savefig(loss_base.with_suffix('.eps'), format='eps', dpi=300)
# plt.savefig(loss_base.with_suffix('.png'), format='png', dpi=300)
# plt.close()

print(acc_eps_path)
print(acc_png_path)
# print(loss_path)